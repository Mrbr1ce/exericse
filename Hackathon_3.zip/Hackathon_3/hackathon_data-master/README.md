# Data Fellowship: Hackathon Data (Sprint 3)

## Introduction
* Spotify Streaming data frovided by Evidence Lab Innovations
* Weekly Track stream counts from December 2016 to March 2019 
* Data is available in files by market for United Kingdom, Ireland, France, Spain, Portugal, Italy, Netherlands, Belgium, Switzerland, Austria, Denmark, Norway, Sweden, and Finland.

## Helpful Hints
1. Download all files as a single zip from https://github.ldn.swissbank.com/AA42799-DATA-FELLOWSHIP/hackathon_data
   * Data filename format = eli_df_hackathon_iso.csv
      * ISO refers to 2-letter country code eg for France the filename would be eli_df_hackathon_FR.csv
   * Extract data files from zip and load into memory
   
```py
import os
import glob
import pandas as pd

path = r"C:\data"
all_filenames = glob.glob(os.path.join(path, "*.csv"))
all_filenames.sort()

li = []
for filename in all_filenames[1:len(all_filenames)]:

    print(filename)
    df = pd.read_csv(filename, index_col=None, header=0,low_memory=False)
    li.append(df)

df = pd.concat(li)
```

2. A single track could have variations in spelling and/or punctuation in different markets i.e. may not be directly comparable
   * An option is to use the unique track_id field for matching of tracks over time and across countries. 
3. Different versions of a track can have different track_id values (e.g. a remix or artist collaboration)
   * For simplicity we dont try to match different version of a track and we rely on just track_id as a unique identifier
4. No need to analyse all of the markets provided e.g. you could limit your analysis to a single market. 
5. The date field is a text object;  try **pd.to_datetime()** to transform to date.
   * Weekly streams can be volatile so it may be worth considering a rolling 4-week stream count. 
6. Not all charts have 200 tracks per week. This is because only songs with 1000+ streams appear in the top charts.
7. A single track does not necessarily appear in a chart in successive periods

## Data Dictionary

|field name|dtype|description|
| ------------- |:-------------:|:-----|
|service_name|character|Source of data (Spotify)|
|chart_period|character|Data frequency (Weekly)|
|chart_date|double|Spotify chart date|
|chart_name|character|Spotify Regional Top 200|
|chart_length|character|200 tracks/week|
|track_name|character|Track name from source (spelling can vary by market)|
|track_id|character|Unique track identifier (can vary by version)|
|artist_name|character|Artist name/s from source|
|track_rank|character|Rank in weekly Top 200 based on stream count|
|track_metric|character|Spotify Streams|
|track_metric_value|character|Stream count by period|
|countryiso|character|2 letter country ISO code|
#

